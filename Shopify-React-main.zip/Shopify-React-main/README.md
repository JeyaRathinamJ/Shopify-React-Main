# Shopify-React
This is just an Basic E Commerce app using MERN stack.
