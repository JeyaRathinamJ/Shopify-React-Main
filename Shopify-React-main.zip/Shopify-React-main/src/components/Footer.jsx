const Footer = () => (
    <footer>
        <p>Company © W3docs. All rights reserved.</p>
    </footer>
);

export default Footer;
